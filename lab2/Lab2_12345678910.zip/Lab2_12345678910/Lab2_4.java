/**

In this task you will implement the method bitPlaneSlicing of the class Lab2_4 which will perform bit plane slicing. Recall that a bit plane is a set of bits corresponding to a given bit position in each of the binary numbers representing the image. In bit plane slicing we will only keeps the bit planes specified in the mask parameter. Note that this mask parameter is specified in the decimal system.

Consider the mask 128. Note that (128)_10 = (1000000)_2
​
and therefore the mask 128 will just keep the most significant bit plane.

Consider the mask 1. Note that (1)_10 = (00000001)_2
​
and therefore the mask 1 will just keep the least significant bit plane.

Consider the mask 192. Note that (192)_10 = (11000000)_2

and therefore the mask 192 will keep the two most significant bit planes.

Similar to task 3 where we implemented the log operation, we also have to perform re-scaling in this task. To perform re-scaling, you may simply divide by the mask and multiply by 255.

The expected output is provided in the files solution1.png, solution128.png and solution192.png for the two thresholds 1, 128 and 192, respectively.

You may use the following command to check if your output is identical to ours.

cmp solution1.png out.png

If this command has no output, it implies that your solution has produced the same file as ours.

**/

import java.util.Scanner;
public class Lab2_4 {
	public Lab2_4() {
		Img img = new Img("Fig0314a.png");
		System.out.print("Mask: ");
		Scanner in = new Scanner(System.in);
		int mask = in.nextInt();
		bitPlaneSlicing(img, mask);
		img.save();
		check(mask);
	}
	/**
     * Implement bit-plane slicing. The mask parameter specifies (in decimal) the
	 * bitplanes that will remain.
     */
	public void bitPlaneSlicing(Img i, int mask) {
		for(int j=0; j< i.img.length; j++){
			int intensity = (int)(i.img[j]&(byte)mask&0XFF);
			intensity = intensity * 255 / mask;
			i.img[j] = (byte)intensity;
		}
	}

	public void check(int mask){
			Img solImg = new Img("solution"+mask+".png");
			Img out = new Img("out.png");
		for(int j=0; j< solImg.img.length; j++){
				if(solImg.img[j] != out.img[j])
				{
						System.out.println("*** incorret byte:" + j);
						System.out.println("solution : "+(int)(solImg.img[j]&0XFF));
						System.out.println("out : "+ (int)(out.img[j]&0XFF));
						break;
				}
		}
	}

	public static void main(String[] args) {
		new Lab2_4();
	}
}
